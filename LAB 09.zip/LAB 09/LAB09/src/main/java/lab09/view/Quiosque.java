package lab09.view;

import lab09.model.AssentoEvent;
import lab09.model.AssentoListener;

public class Quiosque implements AssentoListener {
    @Override
    public void assentoAtualizado(AssentoEvent e) {
        System.out.println("Quiosque: Assento " + e.getNumeroAssento() + " está " + e.getStatus() + "\n");
    }
}
