package lab09.view;

import lab09.model.AssentoEvent;
import lab09.model.AssentoListener;

public class PainelCentral implements AssentoListener {
    @Override
    public void assentoAtualizado(AssentoEvent e) {
        System.out.println("PainelCentral: Assento " + e.getNumeroAssento() +
                " agora está " + e.getStatus() + " (Verde: Disponível, Amarelo: Reservado, Vermelho: Indisponível)");
    }
}
