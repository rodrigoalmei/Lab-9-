package lab09.control;

import lab09.model.Onibus;

public class GuicheController {
    private Onibus onibus;
    private boolean operadorAutorizado;

    public GuicheController(Onibus onibus, boolean operadorAutorizado) {
        this.onibus = onibus;
        this.operadorAutorizado = operadorAutorizado;
    }

    public void reservarAssento(int numeroAssento) {
        if (operadorAutorizado) {
            onibus.reservarAssento(numeroAssento);
        } else {
            throw new SecurityException("Operador não autorizado para reservar assentos.");
        }
    }

    public void indisponibilizarAssento(int numeroAssento) {
        if (operadorAutorizado) {
            onibus.indisponibilizarAssento(numeroAssento);
        } else {
            throw new SecurityException("Operador não autorizado para indisponibilizar assentos.");
        }
    }

    public void liberarAssento(int numeroAssento) {
        if (operadorAutorizado) {
            onibus.liberarAssento(numeroAssento);
        } else {
            throw new SecurityException("Operador não autorizado para liberar assentos.");
        }
    }
}
