package lab09;

import lab09.control.GuicheController;
import lab09.model.Onibus;
import lab09.view.PainelCentral;
import lab09.view.Quiosque;

public class Main {
    public static void main(String[] args) {
        Onibus onibus = new Onibus(10); // Criando um ônibus com 10 assentos
        GuicheController guicheController = new GuicheController(onibus, true);
        PainelCentral painelCentral = new PainelCentral();
        Quiosque quiosque = new Quiosque();

        // Adicionando os listeners
        onibus.addAssentoListener(painelCentral);
        onibus.addAssentoListener(quiosque);

        // Simulando algumas operações
        try {
            guicheController.reservarAssento(1);
            guicheController.indisponibilizarAssento(2);
            guicheController.liberarAssento(1);
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
