package lab09.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Onibus {
    private Map<Integer, AssentoStatus> assentos;
    private List<AssentoListener> listeners = new ArrayList<>();

    public Onibus(int totalAssentos) {
        assentos = new HashMap<>();
        for (int i = 1; i <= totalAssentos; i++) {
            assentos.put(i, AssentoStatus.DISPONIVEL); // Inicializa todos os assentos como disponíveis
        }
    }

    public synchronized void addAssentoListener(AssentoListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public synchronized void removeAssentoListener(AssentoListener listener) {
        listeners.remove(listener);
    }

    private void disparaAssentoAtualizado(int numeroAssento, AssentoStatus status) {
        AssentoEvent event = new AssentoEvent(this, numeroAssento, status);
        for (AssentoListener listener : listeners) {
            listener.assentoAtualizado(event);
        }
    }

    public void reservarAssento(int numeroAssento) {
        if (assentos.get(numeroAssento) == AssentoStatus.DISPONIVEL) {
            assentos.put(numeroAssento, AssentoStatus.RESERVADO);
            disparaAssentoAtualizado(numeroAssento, AssentoStatus.RESERVADO);
        } else {
            throw new IllegalArgumentException("Assento não disponível para reserva.");
        }
    }

    public void indisponibilizarAssento(int numeroAssento) {
        if (assentos.get(numeroAssento) == AssentoStatus.DISPONIVEL) {
            assentos.put(numeroAssento, AssentoStatus.INDISPONIVEL);
            disparaAssentoAtualizado(numeroAssento, AssentoStatus.INDISPONIVEL);
        } else {
            throw new IllegalArgumentException("Assento já reservado ou indisponível.");
        }
    }

    public void liberarAssento(int numeroAssento) {
        // Verifica se o assento existe
        if (!assentos.containsKey(numeroAssento)) {
            throw new IllegalArgumentException("Número do assento inválido.");
        }
        // Verifica se o assento está reservado para ser liberado
        if (assentos.get(numeroAssento) == AssentoStatus.RESERVADO) {
            assentos.put(numeroAssento, AssentoStatus.DISPONIVEL); // Libera o assento
            disparaAssentoAtualizado(numeroAssento, AssentoStatus.DISPONIVEL);
        } else {
            throw new IllegalArgumentException("Assento não está reservado e não pode ser liberado.");
        }
    }

    public AssentoStatus getAssentoStatus(int numeroAssento) {
        // Verifica se o assento existe
        if (!assentos.containsKey(numeroAssento)) {
            throw new IllegalArgumentException("Número do assento inválido.");
        }
        return assentos.get(numeroAssento); // Retorna o status do assento
    }
}
