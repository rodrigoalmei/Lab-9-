package lab09.model;

import java.util.EventObject;

public class AssentoEvent extends EventObject {
    private int numeroAssento;
    private AssentoStatus status;

    public AssentoEvent(Object source, int numeroAssento, AssentoStatus status) {
        super(source);
        this.numeroAssento = numeroAssento;
        this.status = status;
    }

    public int getNumeroAssento() {
        return numeroAssento;
    }

    public AssentoStatus getStatus() {
        return status;
    }
}
