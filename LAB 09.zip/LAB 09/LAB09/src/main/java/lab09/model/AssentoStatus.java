package lab09.model;

public enum AssentoStatus {
    DISPONIVEL,
    RESERVADO,
    INDISPONIVEL
}
