package lab09.model;

import java.util.EventListener;

public interface AssentoListener extends EventListener {
    void assentoAtualizado(AssentoEvent e);
}
