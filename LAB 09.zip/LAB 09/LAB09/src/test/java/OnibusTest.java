import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import lab09.model.AssentoStatus;
import lab09.model.Onibus;

class OnibusTest {
    private Onibus onibus;

    @BeforeEach
    void setUp() {
        onibus = new Onibus(20); // Um ônibus com 20 assentos
    }

    @Test
    void reservarAssentoDisponivel() {
        onibus.reservarAssento(1);
        assertEquals(AssentoStatus.RESERVADO, onibus.getAssentoStatus(1));
    }

    @Test
    void reservarAssentoJaReservado() {
        onibus.reservarAssento(1);
        assertThrows(IllegalArgumentException.class, () -> onibus.reservarAssento(1));
    }

    @Test
    void liberarAssentoReservado() {
        onibus.reservarAssento(1);
        onibus.liberarAssento(1);
        assertEquals(AssentoStatus.DISPONIVEL, onibus.getAssentoStatus(1));
    }

    @Test
    void indisponibilizarAssentoDisponivel() {
        onibus.indisponibilizarAssento(1);
        assertEquals(AssentoStatus.INDISPONIVEL, onibus.getAssentoStatus(1));
    }

    @Test
    void liberarAssentoJaDisponivel() {
        assertThrows(IllegalArgumentException.class, () -> onibus.liberarAssento(1));
    }

    @Test
    void indisponibilizarAssentoJaReservado() {
        onibus.reservarAssento(1);
        assertThrows(IllegalArgumentException.class, () -> onibus.indisponibilizarAssento(1));
    }

    @Test
    void liberarAssentoJaIndisponibilizado() {
        onibus.indisponibilizarAssento(1);
        assertThrows(IllegalArgumentException.class, () -> onibus.liberarAssento(1));
    }

    @Test
    void getAssentoStatusAssentoInvalido() {
        assertThrows(IllegalArgumentException.class, () -> onibus.getAssentoStatus(21)); // Assento fora do intervalo
}

}
