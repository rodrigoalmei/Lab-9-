import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import lab09.control.GuicheController;
import lab09.model.AssentoStatus;
import lab09.model.Onibus;

class GuicheControllerTest {
    private Onibus onibus;
    private GuicheController guicheController;

    @BeforeEach
    void setUp() {
        onibus = new Onibus(20);
    }

    @Test
    void operadorAutorizadoPodeReservarAssento() {
        guicheController = new GuicheController(onibus, true);
        guicheController.reservarAssento(1);
        assertEquals(AssentoStatus.RESERVADO, onibus.getAssentoStatus(1));
    }

    @Test
    void operadorNaoAutorizadoNaoPodeReservarAssento() {
        guicheController = new GuicheController(onibus, false);
        assertThrows(SecurityException.class, () -> guicheController.reservarAssento(1));
    }

    @Test
    void operadorAutorizadoPodeIndisponibilizarAssento() {
        guicheController = new GuicheController(onibus, true);
        guicheController.indisponibilizarAssento(1);
        assertEquals(AssentoStatus.INDISPONIVEL, onibus.getAssentoStatus(1));
    }

    @Test
    void operadorNaoAutorizadoNaoPodeIndisponibilizarAssento() {
        guicheController = new GuicheController(onibus, false);
        assertThrows(SecurityException.class, () -> guicheController.indisponibilizarAssento(1));
    }

    @Test
    void operadorAutorizadoPodeLiberarAssento() {
        guicheController = new GuicheController(onibus, true);
        guicheController.reservarAssento(1);
        guicheController.liberarAssento(1);
        assertEquals(AssentoStatus.DISPONIVEL, onibus.getAssentoStatus(1));
    }

    @Test
    void operadorNaoAutorizadoNaoPodeLiberarAssento() {
        guicheController = new GuicheController(onibus, false);
        assertThrows(SecurityException.class, () -> guicheController.liberarAssento(1));
    }
}
